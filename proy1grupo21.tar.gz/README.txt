********************************************************************************
*                                                                              *
*                                     README                                   *
*                                                                              *
********************************************************************************

Desarrollado por:

    Luis Fernandes 10-10239 <lfernandes@ldc.usb.ve>
    Rebeca Machado 10-10406 <rebeca@ldc.usb.ve>
    
    
ARCHIVOS INCLUÍDOS EN LA ENTREGA
================================

  schat.c
  cchat.c
  lista.c
  htip.c
  README.txt
  errors.h
  errors.c
  
  
MODO DE INVOCACIÓN
==================

  1. Ejecutar
    &> make
    
  2. Ejecutar
  
    &> ./schat -p <puerto> [-s <sala>]
    
  3. Ejecutar
    
    &> ./cchat -h <host> -p <puerto> -n <nombre> [-a <archivo>]